package com.campass.demo.exception;

public class MemberNotFoundException extends RuntimeException {

}
