package com.campass.demo.entity;


public class bCategori {
	private Integer bCateCode;
	private String bCateName;
}
	